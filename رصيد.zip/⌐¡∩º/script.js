// script.js

let userBalance = 100000; // رصيد المستخدم بالـ دينار العراقي
let userName = ''; // اسم المستخدم
let isLoggedIn = false; // حالة الدخول

// دالة لتسجيل الدخول أو إنشاء الحساب
document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();
    userName = document.getElementById("username").value;
    let password = document.getElementById("password").value;
    
    // تسجيل الدخول بنجاح
    if (userName && password) {
        isLoggedIn = true;
        document.getElementById("loginPage").style.display = 'none';
        document.getElementById("appPage").style.display = 'block';

        // تحديث الرصيد في التطبيق
        document.getElementById("balance").textContent = userBalance;
    } else {
        alert("يرجى إدخال جميع البيانات بشكل صحيح.");
    }
});

// دالة لتوليد كود رصيد عشوائي
function generateCardCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 10; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
}

// دالة لتحويل العملة إلى الدولار (من أجل التنسيق)
function convertToDollar(dinar) {
    const exchangeRate = 1.42; // سعر الصرف (من دينار عراقي إلى دولار)
    return (dinar / exchangeRate).toFixed(2);
}

// عند الضغط على زر الدفع
document.getElementById("payButton").addEventListener("click", function() {
    // الحصول على المبلغ المختار
    let selectedAmount = parseInt(document.getElementById("amount").value);

    // التحقق من الرصيد المتاح
    if (userBalance >= selectedAmount) {
        // إذا كان الرصيد كافٍ، خصم المبلغ وإتمام الدفع
        userBalance -= selectedAmount;
        document.getElementById("balance").textContent = userBalance;

        // توليد كود الرصيد
        const cardCode = generateCardCode();

        // تحويل المبلغ إلى دولار لعرضه في حال رغبت في ذلك
        let dollarAmount = convertToDollar(selectedAmount);

        // عرض رسالة التأكيد
        document.getElementById("confirmationMessage").style.display = "block";

        // تحديث قيمة المبلغ في رسالة التأكيد
        document.getElementById("selectedAmount").textContent = `${selectedAmount} دينار`;

        // عرض كود الرصيد
        document.getElementById("cardCode").textContent = cardCode;
    } else {
        // إذا كان الرصيد غير كافٍ
        alert("رصيدك غير كافٍ لإتمام هذه المعاملة.");
    }
});

// دالة لطباعة كارت الرصيد مع الشعار
document.getElementById("printCardButton").addEventListener("click", function() {
    const cardCode = document.getElementById("cardCode").textContent;
    const selectedAmount = document.getElementById("selectedAmount").textContent;

    const printWindow = window.open('', '', 'width=600,height=400');
    printWindow.document.write(`
        <html>
            <head>
                <title>طباعة كارت الرصيد</title>
                <style>
                    body { font-family: Arial, sans-serif; text-align: center; }
                    .card { border: 1px solid #333; padding: 20px; display: inline-block; font-size: 20px; }
                    .card-code { font-weight: bold; color: #FF6347; }
                    .company-logo { width: 100px; margin-bottom: 10px; }
                    .app-logo { width: 150px; margin-top: 20px; }
                </style>
            </head>
            <body>
                <img src="company-logo.png" alt="شعار الشركة" class="company-logo">
                <img src="logo.png" alt="شعار التطبيق" class="app-logo">
                <div class="card">
                    <p>تم شراء رصيد بقيمة ${selectedAmount}</p>
                    <p>كود الرصيد: <span class="card-code">${cardCode}</span></p>
                </div>
            </body>
        </html>
    `);
    printWindow.document.close();
    printWindow.print();
});

// دالة لتجربة الطباعة
document.getElementById("printTestButton").addEventListener("click", function() {
    const testMessage = "تجربة الطباعة: تم إجراء عملية الدفع بنجاح!";
    const printWindow = window.open('', '', 'width=600,height=400');
    printWindow.document.write(`
        <html>
            <head>
                <title>تجربة الطباعة</title>
                <style>
                    body { font-family: Arial, sans-serif; text-align: center; }
                </style>
            </head>
            <body>
                <p>${testMessage}</p>
            </body>
        </html>
    `);
    printWindow.document.close();
    printWindow.print();
});

// دالة لشحن رصيد الألعاب (ببجي ولودو)
document.querySelectorAll(".game-btn").forEach(button => {
    button.addEventListener("click", function() {
        const game = this.getAttribute("data-game");
        alert(`تم شحن رصيد لعبة ${game} بنجاح!`);
    });
});
